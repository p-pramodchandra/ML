import cv2
from keras.models import model_from_json
import numpy as np
import time
#import controller as cnt
path_emotion_model=r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Emotion_detection_with_CNN-main\model\emotion_model.json'
path_model_h5=r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Emotion_detection_with_CNN-main\model\emotion_model.h5'
# from keras_preprocessing.image import load_img
json_file = open(path_emotion_model)
model_json = json_file.read()
json_file.close()
model = model_from_json(model_json)

model.load_weights(path_model_h5)
haar_file=cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
face_cascade=cv2.CascadeClassifier(haar_file)

def extract_features(image):
    feature = np.array(image)
    feature = feature.reshape(1,48,48,1)
    return feature/255.0

webcam=cv2.VideoCapture(0)
labels = {0 : 'angry', 1 : 'disgust', 2 : 'fear', 3 : 'happy', 4 : 'neutral', 5 : 'sad', 6 : 'surprise'}


# Define a variable to keep track of the last time an emotion was predicted
last_prediction_time = 0

while True:
    i, im = webcam.read()
    gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(im, 1.3, 5)

    try: 
        for (p, q, r, s) in faces:
            image = gray[q:q+s, p:p+r]
            cv2.rectangle(im, (p, q), (p+r, q+s), (255, 0, 0), 2)
            image = cv2.resize(image, (48, 48))
            img = extract_features(image)
            pred = model.predict(img)
            prediction_label = labels[pred.argmax()]

            current_time = time.time()
            
            # Check if at least 5 seconds have passed since the last prediction
            if current_time - last_prediction_time >= 5:
                cv2.putText(im, '% s' % (prediction_label), (p-10, q-10), cv2.FONT_HERSHEY_COMPLEX_SMALL, 2, (0, 0, 255))
                last_prediction_time = current_time
                print(prediction_label)
               # cnt.predicted_label(prediction_label)
            
        cv2.imshow("Output", im)
        cv2.waitKey(27)
    except cv2.error:
        pass

while True:
    i,im=webcam.read()
    gray=cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)
    faces=face_cascade.detectMultiScale(im,1.3,5)
    try: 
        for (p,q,r,s) in faces:
            image = gray[q:q+s,p:p+r]
            cv2.rectangle(im,(p,q),(p+r,q+s),(255,0,0),2)
            image = cv2.resize(image,(48,48))
            img = extract_features(image)
            pred = model.predict(img)
            prediction_label = labels[pred.argmax()]
            # print("Predicted Output:", prediction_label)
            # cv2.putText(im,prediction_label)
            cv2.putText(im, '% s' %(prediction_label), (p-10, q-10),cv2.FONT_HERSHEY_COMPLEX_SMALL,2, (0,0,255))
        cv2.imshow("Output",im)
        cv2.waitKey(27)
    except cv2.error:
        pass