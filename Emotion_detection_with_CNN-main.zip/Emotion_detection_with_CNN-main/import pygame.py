import pygame

# Define the label-music mapping
music_mapping = {
    0: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Fujitora theme.mp3',
    1: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Luffy Singss.mp3',
    2: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Nami theme.mp3',
    3: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\One Piece Overtaken.mp3',
    4: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Sake binks.mp3',
    5: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Sanji Fight Back.mp3',
    6: r'C:\Users\Priyeshwar\Desktop\Emotion_detection_with_CNN\Very Very Strongest.mp3'
}

# Initialize pygame
pygame.init()

# Function to play music
def play_music(file):
    pygame.mixer.music.load(file)
    pygame.mixer.music.play()

# Hypothetical emotion prediction (replace this with the actual output from your model)
predicted_emotion_label = 1  # Example: Happy

# Retrieve the associated music file
music_file = music_mapping.get(predicted_emotion_label, 'default_music.mp3')

# Play the music
play_music(music_file)

# Wait for the music to finish (optional)
pygame.time.wait(1000000)  # Adjust the time based on your music length or remove this line

# Quit pygame
pygame.quit()
