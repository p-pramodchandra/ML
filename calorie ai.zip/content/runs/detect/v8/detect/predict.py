# Ultralytics YOLO 🚀, GPL-3.0 license

import hydra
import torch

from ultralytics.yolo.engine.predictor import BasePredictor
from ultralytics.yolo.utils import DEFAULT_CONFIG, ROOT, ops
from ultralytics.yolo.utils.checks import check_imgsz
from ultralytics.yolo.utils.plotting import Annotator, colors, save_one_box


class DetectionPredictor(BasePredictor):

    def get_annotator(self, img):
        return Annotator(img, line_width=self.args.line_thickness, example=str(self.model.names))

    def preprocess(self, img):
        img = torch.from_numpy(img).to(self.model.device)
        img = img.half() if self.model.fp16 else img.float()  # uint8 to fp16/32
        img /= 255  # 0 - 255 to 0.0 - 1.0
        return img

    def postprocess(self, preds, img, orig_img):
        preds = ops.non_max_suppression(preds,
                                        self.args.conf,
                                        self.args.iou,
                                        agnostic=self.args.agnostic_nms,
                                        max_det=self.args.max_det)

        for i, pred in enumerate(preds):
            shape = orig_img[i].shape if self.webcam else orig_img.shape
            pred[:, :4] = ops.scale_boxes(img.shape[2:], pred[:, :4], shape).round()

        return preds

    def write_results(self, idx, preds, batch):
        p, im, im0 = batch
        log_string = ""
        if len(im.shape) == 3:
            im = im[None]  # expand for batch dim
        self.seen += 1
        im0 = im0.copy()
        if self.webcam:  # batch_size >= 1
            log_string += f'{idx}: '
            frame = self.dataset.count
        else:
            frame = getattr(self.dataset, 'frame', 0)

        self.data_path = p
        # save_path = str(self.save_dir / p.name)  # im.jpg
        self.txt_path = str(self.save_dir / 'labels' / p.stem) + ('' if self.dataset.mode == 'image' else f'_{frame}')
        log_string += '%gx%g ' % im.shape[2:]  # print string
        self.annotator = self.get_annotator(im0)

        det = preds[idx]
        self.all_outputs.append(det)
        if len(det) == 0:
            return log_string
        for c in det[:, 5].unique():
            n = (det[:, 5] == c).sum()  # detections per class
            log_string += f"{n} {self.model.names[int(c)]}{'s' * (n > 1)}, "
        # write
        gn = torch.tensor(im0.shape)[[1, 0, 1, 0]]  # normalization gain whwh
        for *xyxy, conf, cls in reversed(det):
            c = int(cls)  # integer class
            label = self.model.names[c]  # Get the label for the predicted class
            print(f'Predicted Label: {label}')  # Print the label
            x_min, y_min, x_max, y_max = xyxy
            width = x_max - x_min
            height = y_max - y_min
            area = width * height

            print(f'Predicted Label: {label}, Area: {area:.2f} square units')
            calorie_dict = {
                'AW cola': 150,
                'Beijing Beef': 350,
                'Chow Mein': 400,
                'Fried Rice': 350,
                'Hashbrown': 150,
                'Honey Walnut Shrimp': 300,
                'Kung Pao Chicken': 400,
                'String Bean Chicken Breast': 350,
                'Super Greens': 100,
                'The Original Orange Chicken': 500,
                'White Steamed Rice': 200,
                'bakso': 250,
                'black pepper rice bowl': 450,
                'burger': 300,
                'carrot_eggs': 150,
                'cheese balls': 200,
                'cheese burger': 350,
                'chicken waffle': 400,
                'chicken_nuggets': 300,
                'chinese_cabbage': 50,
                'chinese_sausage': 200,
                'crispy corn': 150,
                'curry': 300,
                'french fries': 200,
                'fried chicken': 250,
                'fried_chicken': 250,
                'fried_dumplings': 300,
                'fried_eggs': 200,
                'friedchicken': 250,
                'mango chicken pocket': 350,
                'mozza burger': 350,
                'mung_bean_sprouts': 50,
                'nugget': 200,
                'perkedel': 150,
                'prin cheese balls': 200,
                'prin cheese stick': 250,
                'prin hotdog': 300,
                'prin mianbao sia': 250,
                'rice': 200,
                'sate': 350,
                'sausage and rice cake': 300,
                'sprite': 150,
                'tostitos cheese dip sauce': 100,
                'triangle_hash_brown': 150,
                'water_spinach': 50
            }
            if label in calorie_dict:
                calorie_count = calorie_dict[label]
                calorie=calorie_count*(area/10000)
                print(f"the calorie in the food {label} is {calorie/3}")


            if self.args.save_txt:  # Write to file
                xywh = (ops.xyxy2xywh(torch.tensor(xyxy).view(1, 4)) / gn).view(-1).tolist()  # normalized xywh
                line = (cls, *xywh, conf) if self.args.save_conf else (cls, *xywh)  # label format
                with open(f'{self.txt_path}.txt', 'a') as f:
                    f.write(('%g ' * len(line)).rstrip() % line + '\n')

            if self.args.save or self.args.save_crop or self.args.show:  # Add bbox to image
                c = int(cls)  # integer class
                label = None if self.args.hide_labels else (
                    self.model.names[c] if self.args.hide_conf else f'{self.model.names[c]} {conf:.2f}')
                self.annotator.box_label(xyxy, label, color=colors(c, True))
            if self.args.save_crop:
                imc = im0.copy()
                save_one_box(xyxy,
                             imc,
                             file=self.save_dir / 'crops' / self.model.model.names[c] / f'{self.data_path.stem}.jpg',
                             BGR=True)

        return log_string


@hydra.main(version_base=None, config_path=str(DEFAULT_CONFIG.parent), config_name=DEFAULT_CONFIG.name)
def predict(cfg):
    cfg.model = cfg.model
    cfg.imgsz = check_imgsz(cfg.imgsz, min_dim=2)  # check image size
    cfg.source = cfg.source if cfg.source is not None else ROOT / "assets"
    predictor = DetectionPredictor(cfg)
    predictor()


if __name__ == "__main__":
    predict()
